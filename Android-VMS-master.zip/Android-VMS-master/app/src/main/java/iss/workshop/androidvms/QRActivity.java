package iss.workshop.androidvms;

import com.journeyapps.barcodescanner.CaptureActivity;

public class QRActivity extends CaptureActivity {
}
